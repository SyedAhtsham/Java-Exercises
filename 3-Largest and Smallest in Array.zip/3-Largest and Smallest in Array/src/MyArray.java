import java.util.Random;



public class MyArray {

	public static void main(String[] args) {
		System.out.println("This Program prints the Smallest, Largest number and Sort an Array");
		System.out.println();

		Random rand = new Random();

		int[] myArray = {7, 4, 2, 5, 6, 10, 3, 9, 1, 8};

		
		System.out.println("Printing myArray Elements");
		System.out.println();

		for (int i = 0; i < myArray.length; i++) {
			System.out.println("myArray[" + i + "] = " + myArray[i]);
		}
		
		
		int myLargest;
		int mySmallest = myLargest = myArray[0];
		
		for (int i = 0; i < myArray.length; i++) {
			if(mySmallest > myArray[i]) {
				mySmallest = myArray[i];
				
			}
			
			if(myLargest < myArray[i])
			{
				myLargest = myArray[i];
			}
			
		}
		
		System.out.println();
		System.out.println("Smallest Number in the Array: "+ mySmallest);
		System.out.println();
		System.out.println("Largest Number in the Array: " + myLargest);
		
		System.out.println();
		
		for (int i = 0; i < myArray.length-1; i++) {
			for (int j = 0; j < myArray.length-i-1; j++) {
				
				if(myArray[j]>myArray[j+1]) {
					int temp = myArray[j];
					myArray[j] = myArray[j+1];
					myArray[j+1] = temp;
				}
				
			}
		}
		
		
		
		System.out.println("Printing myArray Elements in Ascending Order");
		System.out.println();

		for (int i = 0; i < myArray.length; i++) {
			System.out.println("myArray[" + i + "] = " + myArray[i]);
		}
		
		for (int i = 0; i < myArray.length-1; i++) {
			for (int j = 0; j < myArray.length-i-1; j++) {
				
				if(myArray[j]<myArray[j+1]) {
					int temp = myArray[j];
					myArray[j] = myArray[j+1];
					myArray[j+1] = temp;
				}
				
			}
		}
		
		System.out.println();
		System.out.println("Printing myArray Elements in Descending Order");
		System.out.println();

		for (int i = 0; i < myArray.length; i++) {
			System.out.println("myArray[" + i + "] = " + myArray[i]);
		}
		
		
	}
}
