import java.util.*;


public class ReverseString {

	public static void reverseStr(String input, int lastIndex) {
		
		if(lastIndex < 0){
	        
	        return;
	    }else{
	        
	    int i=0;
	    
	    for(i = lastIndex-1; i >=0 && input.charAt(i) != ' '; i--);
	    
	    for(int k = i+1; k < lastIndex; k++){
	        
	    	System.out.print(input.charAt(k));
	    }
	    System.out.print(" ");
	        
	    
	    reverseStr(input, i);
	    }
	    
	}
	
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		
		String userInputString = "";
		
		System.out.print("Enter a String: ");
		
		userInputString = sc.nextLine();
		
		sc.close();
		int index = userInputString.length();
		
		reverseStr(userInputString, index);
	}
	
}
