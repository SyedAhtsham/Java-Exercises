import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Birthdate {
	
	
	 public static Date parseDate(String date) {
	     try {
	         return new SimpleDateFormat("dd-MM-yyyy").parse(date);
	     } catch (ParseException e) {
	         return null;
	     }
	  }

	public static void main(String[] args) {
		
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate locatDate = LocalDate.now();

		
		
	
		String[] splittedStrings = args[0].split("-");
		String todayDate = dtf.format(locatDate);
		int[] birthdateArr = new int[3];
		int[] todayDateArr = new int[3];
		String[] splittedTodayDate = todayDate.split("-");
//		System.out.println(dtf.format(locatDate));

		try {
			System.out.println("My Birthdate: " + args[0]);
			

			for (int i = 0; i < 3; i++) {
				birthdateArr[i] = Integer.parseInt(splittedStrings[i]);
				todayDateArr[i] = Integer.parseInt(splittedTodayDate[i]);
//				System.out.println(birthdateArr[i]);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		int birthDateYears = todayDateArr[2] - birthdateArr[2];

		int tempMonths = todayDateArr[1] - birthdateArr[1];
		if (todayDateArr[1] < birthdateArr[1]) {
			--birthDateYears;
			tempMonths = (12 - birthdateArr[1]) + todayDateArr[1];

		}
		int birthInDays = todayDateArr[0] - birthdateArr[0];
		if (todayDateArr[0] < birthdateArr[0]) {

			int temp = todayDateArr[0] + 31;
			birthInDays = temp - birthdateArr[0];
			tempMonths--;
		}

		System.out.println(
				"My Age in Years: " + birthDateYears + " Years " + tempMonths + " Months " + birthInDays + " Days");

		int totalMonths = birthDateYears*12 + tempMonths;
		
		int totalDays = birthDateYears * 365 + tempMonths* 30 + birthInDays;
		
		System.out.println(
				"My Age in Months: " + totalMonths + " Months " + birthInDays + " Days");

		
		System.out.println(
				"My Age in Days: " + totalDays + " Days");
		
	      String[] days = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

	      
	  	System.out.println();
		System.out.println("My Birthday in Each Year Since I was born:");
		System.out.println();
		for (int i = birthdateArr[2]; i < todayDateArr[2]; i++) {
			Calendar c = Calendar.getInstance();
			
			Date date = parseDate(splittedStrings[0]+"-"+splittedStrings[1]+"-"+String.valueOf(i));
			
			c.setTime(date);
			
		
			System.out.println(String.valueOf(i)+": "+ days[c.get(Calendar.DAY_OF_WEEK)-1]);
		}
		
	}
}
