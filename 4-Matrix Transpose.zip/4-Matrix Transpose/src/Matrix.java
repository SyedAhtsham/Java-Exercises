
public class Matrix {

	
	public static int[][] takeTranspose(int[][] matrix, int rowSize, int colSize)
	{
		int[][] matrixTranspose = new int[colSize][rowSize];
		
		for (int i = 0; i < rowSize; i++) {
			for (int j = 0; j < colSize; j++) {
				matrixTranspose[j][i] = matrix[i][j];
			}
		}
		
		return matrixTranspose;
	}
	
	
	public static void printMatrix(int[][] matrix, int rowSize, int colSize)
	{
		for (int i = 0; i < rowSize; i++) {
			for (int j = 0; j < colSize; j++) {
				System.out.print(matrix[i][j] + "\t");
			}
			System.out.println();
			System.out.println();
		}

	}
	
	public static void main(String[] args) {
		
		
		System.out.println("This program prints transpose of a Matrix");
		System.out.println();
		System.out.println();
		int[][] matrix = { { 2, 4, 5, 6 }, { 7, 8, 9, 10 }, { 11, 12, 14, 15 }, { 0, -9, 18, 19 }, { -1, 23, 22, 17 } };

		System.out.println("Printing Matrix Before Transpose");
		System.out.println();
		
		printMatrix(matrix, 5, 4);
		
		

		System.out.println();
		System.out.println("Printing Matrix After Transpose");
		System.out.println();
		
		int[][] matrixTranspose = takeTranspose(matrix, 5, 4);
		
		printMatrix(matrixTranspose, 4, 5);

	}
}
