

public class MyString {

	

	public static void main(String[] args)
	{
		System.out.println("This Program letter count in a given string");
		System.out.println();
		
		
		
		String strObj = "Syed Ahtsham Ul Hassan";
		System.out.println("Orignal String: " + strObj);
		System.out.println();
		
		System.out.println("Letter\tCount");
		System.out.println();
	
		int[] arr = new int[strObj.length()];
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = 0;
		}
		
		Node[] nodeArr = new Node[strObj.length()];
		
		for (int i = 0; i < nodeArr.length; i++) {
			nodeArr[i] = new Node();
		}
		
		int k=0, l;
		boolean isExist = false;
			for(int i=0; i<strObj.length(); i++)
			{
				for( l=0; l<nodeArr.length; l++)
				{
					try {
					if(strObj.charAt(i) == nodeArr[l].letter) {
						isExist = true;
						break;
					}
					}
					
					catch (NullPointerException e) {
						System.out.println(e);
					}
				}
				if(isExist) {
					isExist = false;
					continue;
				}
				for(int j=0; j<strObj.length(); j++)
				{
					if(strObj.charAt(i) == strObj.charAt(j))
					{
						for( l=0; l<nodeArr.length; l++)
						{
							try {
							if(strObj.charAt(i) == nodeArr[l].letter) {
								isExist = true;
								break;
							}
							}
							
							catch (NullPointerException e) {
								System.out.println(e);
							}
						}
						if(!isExist) {
						nodeArr[k].letter = (char) strObj.charAt(i);
						nodeArr[k].count += 1;
						k++;
						}
						else{
							nodeArr[l].count += 1;
						}
						isExist = false;
						
						
					}
					
				}
							
				
		}
			
		for (int i=0; i<k; i++) {
			
			System.out.println(nodeArr[i].letter+":\t" + nodeArr[i].count);
		}
		
	}
}
