public class Node{
		public int count = 0;
		public char letter = ' ';
		
		Node()
		{
			this.count = 0;
			this.letter = '$';
		}
	}
	