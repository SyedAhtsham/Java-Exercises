
public class Tables {

	public static void main(String[] args) {
		System.out.println("This Program prints Multiplication Tables upto 10");
		System.out.println();

		for (int i = 1; i <= 10; i++) {
			System.out.println("Multiplication Table of " + i);
			System.out.println();
			for (int j = 1; j <= 10; j++) {

				System.out.println(i + " * " + j + " = " + (i * j));
			}
			System.out.println();
		}
	}
}
